from django.shortcuts import render

# Create your views here.


from .models import User, Post

#landing page
def index(request):
	return render(request, 'esko_app/index.html')
